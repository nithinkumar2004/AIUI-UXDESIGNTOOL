import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available, but do not expose it in the UI.
// This should be set in the deployment environment.
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates UI code from a user prompt using the Gemini API.
 * @param prompt The user's design description.
 * @returns A string containing the generated HTML code.
 */
export const generateUiCode = async (prompt: string): Promise<string> => {
  const model = "gemini-2.5-flash";

  const fullPrompt = `
    You are an expert web developer specializing in creating modern and aesthetic UIs with Tailwind CSS.
    Your task is to generate a single, complete, and visually appealing HTML file based on the user's prompt.

    **CRITICAL REQUIREMENTS:**
    1.  **Single File Output:** Provide all the code in a single HTML file.
    2.  **Tailwind CSS:** You MUST use Tailwind CSS for all styling. You MUST include the Tailwind CDN script in the <head>: <script src="https://cdn.tailwindcss.com"></script>.
    3.  **No Custom CSS/JS:** Do not use any inline 'style' attributes, <style> blocks, or external/internal JavaScript. All styling must be done with Tailwind classes.
    4.  **Content:** Use relevant placeholder text. For images, use 'https://picsum.photos/seed/picsum/width/height' for dynamic placeholders. Make the design clean, modern, and responsive. Use high-quality design principles.
    5.  **Code Format:** Wrap the entire HTML code in a single markdown block like this: \`\`\`html ... \`\`\`
    6.  **No Explanations:** Do not add any conversational text, explanations, or notes outside of the HTML code block. Your entire response must be only the code block.

    **User's Design Prompt:** "${prompt}"
  `;

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: fullPrompt
    });

    const code = response.text;
    
    // Extract code from the markdown block
    const match = code.match(/```html\n([\s\S]*?)\n```/);
    
    if (match && match[1]) {
      return match[1].trim();
    } else {
      // If the model doesn't follow the format, try to return the raw response, assuming it might be code.
      // A more robust solution could try to clean it, but this is a fallback.
      if (code.trim().startsWith('<!DOCTYPE html>')) {
        return code.trim();
      }
      throw new Error("Could not extract HTML code from the AI's response. The model may have deviated from the required format.");
    }
  } catch (error) {
    console.error("Error generating UI code:", error);
    if (error instanceof Error && error.message.includes('API key not valid')) {
       throw new Error("The configured API key is invalid. Please check your server configuration.");
    }
    throw new Error("Failed to generate UI code. The AI service may be temporarily unavailable.");
  }
};