import React from 'react';

interface WelcomeSplashProps {
  isLoading: boolean;
}

const GeneratingState: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-center p-8 animate-pulse">
      <div className="w-16 h-16 mb-4">
        <svg className="w-full h-full text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c.251.023.501.05.75.082m.75.082a24.301 24.301 0 014.5 0m4.5 0a24.301 24.301 0 01-4.5 0m-4.5 0a24.301 24.301 0 00-4.5 0M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>
      <h3 className="text-xl font-semibold text-gray-200">Generating your design...</h3>
      <p className="text-gray-400 mt-2">The AI is warming up its creative circuits. This might take a moment.</p>
    </div>
);

const InitialState: React.FC = () => (
  <div className="flex flex-col items-center justify-center h-full text-center p-8">
    <div className="w-24 h-24 mb-6 text-gray-600">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-full h-full">
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 1 1-3 0m3 0a1.5 1.5 0 1 0-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m-9.75 0h9.75" />
      </svg>
    </div>
    <h3 className="text-2xl font-bold text-gray-200">Your UI Preview Awaits</h3>
    <p className="text-gray-400 mt-2 max-w-md">
      Describe a component, a page, or even a full layout, and watch the AI bring it to life here.
      Your generated preview and code will appear in this panel.
    </p>
  </div>
);


export const WelcomeSplash: React.FC<WelcomeSplashProps> = ({ isLoading }) => {
  return (
    <div className="h-full w-full bg-gray-800 rounded-b-lg">
      {isLoading ? <GeneratingState /> : <InitialState />}
    </div>
  );
};