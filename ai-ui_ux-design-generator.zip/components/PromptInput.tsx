import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

interface PromptInputProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

export const PromptInput: React.FC<PromptInputProps> = ({ prompt, setPrompt, onGenerate, isLoading }) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      onGenerate();
    }
  };

  return (
    <div className="flex flex-col gap-4 bg-gray-800/50 border border-gray-700 p-4 rounded-lg shadow-lg">
      <label htmlFor="prompt-input" className="text-lg font-semibold text-gray-200">
        Describe the UI you want to create
      </label>
      <textarea
        id="prompt-input"
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="e.g., A modern login page with a dark theme and a glassmorphism effect for the form."
        className="w-full h-48 p-3 bg-gray-900 border border-gray-600 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200 resize-none text-gray-300 placeholder-gray-500"
        disabled={isLoading}
      />
      <div className="flex justify-end items-center">
         <span className="text-xs text-gray-400 mr-4">
            Press <kbd className="font-sans border border-gray-500 rounded px-1.5 py-0.5">Ctrl</kbd> + <kbd className="font-sans border border-gray-500 rounded px-1.5 py-0.5">Enter</kbd> to generate
        </span>
        <button
          onClick={onGenerate}
          disabled={isLoading || !prompt}
          className="flex items-center justify-center px-6 py-2.5 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-500/50 disabled:bg-indigo-900/50 disabled:cursor-not-allowed disabled:text-gray-400 transition-all duration-300 transform hover:scale-105 disabled:scale-100"
        >
          {isLoading ? (
            <>
              <LoadingSpinner />
              Generating...
            </>
          ) : (
            'Generate UI'
          )}
        </button>
      </div>
    </div>
  );
};