import React, { useState, useEffect } from 'react';
import Editor from 'react-simple-code-editor';
import Prism from 'prismjs/components/prism-core';
import 'prismjs/components/prism-markup';
import { ClipboardIcon, CheckIcon } from './icons/Icons';


interface CodeDisplayProps {
  code: string;
  setCode: (code: string) => void;
}

export const CodeDisplay: React.FC<CodeDisplayProps> = ({ code, setCode }) => {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code).then(() => {
      setIsCopied(true);
    });
  };

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => setIsCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  return (
    <div className="h-full w-full bg-[#282c34] relative animate-fade-in group">
      <button
        onClick={handleCopy}
        className="absolute top-3 right-3 p-2 bg-gray-700/50 rounded-lg text-gray-300 hover:bg-gray-600 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 z-10"
        aria-label="Copy code to clipboard"
      >
        {isCopied ? <CheckIcon className="text-green-400" /> : <ClipboardIcon />}
      </button>
      <Editor
        value={code}
        onValueChange={setCode}
        highlight={code => Prism.highlight(code, Prism.languages.markup, 'markup')}
        padding={20}
        className="h-full w-full"
        textareaClassName="outline-none"
        style={{
          fontFamily: '"Fira Code", monospace',
          fontSize: '0.875rem',
          color: '#f8f8f2',
          caretColor: '#f8f8f2'
        }}
      />
    </div>
  );
};