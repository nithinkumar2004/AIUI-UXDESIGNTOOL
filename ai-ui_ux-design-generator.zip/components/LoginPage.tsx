import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // No real validation for this demo
    if (email && password) {
      onLogin();
    } else {
        alert("Please enter an email and password.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-md animate-fade-in">
        <form 
          onSubmit={handleSubmit}
          className="bg-gray-800/50 border border-gray-700 rounded-2xl shadow-2xl p-8 space-y-6"
        >
          <div className="flex flex-col items-center space-y-2">
             <div className="w-12 h-12 bg-gradient-to-tr from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c.251.023.501.05.75.082m.75.082a24.301 24.301 0 014.5 0m4.5 0a24.301 24.301 0 01-4.5 0m-4.5 0a24.301 24.301 0 00-4.5 0m-4.5 0a24.293 24.293 0 00-1.606 2.083c-.438.64.08 1.56 1.084 1.56h14.444c1.004 0 1.522-.92.084-1.56a24.293 24.293 0 00-1.606-2.083m-12.75 0a24.293 24.293 0 0112.75 0m-12.75 0c-.249-.03-.5-.059-.75-.082m-.75-.082c-1.632.146-2.946 1.49-2.946 3.132v5.714c0 .828.672 1.5 1.5 1.5h1.25m1.25 0h1.25m-1.25 0a2.25 2.25 0 01-2.25-2.25V15m2.25 2.25h1.25m1.25 0h1.25m-1.25 0a2.25 2.25 0 01-2.25-2.25V15m2.25 2.25h1.25m1.25 0h1.25m-1.25 0a2.25 2.25 0 01-2.25-2.25V15m2.25 2.25h1.25m1.25 0h.008v.008h-.008v-.008zm.008 0a2.25 2.25 0 01-2.25-2.25V15m2.25 2.25h1.25c.828 0 1.5-.672 1.5-1.5V9.816c0-1.642-1.314-2.986-2.946-3.132" />
                </svg>
            </div>
            <h1 className="text-2xl font-bold text-gray-100">Welcome Back</h1>
            <p className="text-gray-400">Sign in to continue to the AI UI Generator</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 block mb-2" htmlFor="email">Email Address</label>
              <input 
                type="email" 
                id="email" 
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="w-full px-4 py-2 bg-gray-900 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200 text-gray-300"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 block mb-2" htmlFor="password">Password</label>
              <input 
                type="password" 
                id="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                className="w-full px-4 py-2 bg-gray-900 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors duration-200 text-gray-300"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full px-6 py-3 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-500/50 transition-all duration-300"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;