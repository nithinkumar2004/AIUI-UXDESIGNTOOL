import React, { useState } from 'react';
import { Preview } from './Preview';
import { CodeDisplay } from './CodeDisplay';
import { EyeIcon, CodeBracketIcon } from './icons/Icons';

interface OutputPanelProps {
  code: string;
  setCode: (code: string) => void;
}

type ActiveTab = 'preview' | 'code';

export const OutputPanel: React.FC<OutputPanelProps> = ({ code, setCode }) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('preview');

  const TabButton: React.FC<{
    tabName: ActiveTab;
    label: string;
    icon: React.ReactNode;
  }> = ({ tabName, label, icon }) => (
    <button
      onClick={() => setActiveTab(tabName)}
      className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-t-lg transition-colors duration-200 ${
        activeTab === tabName
          ? 'bg-gray-800 text-white border-b-2 border-indigo-500'
          : 'text-gray-400 hover:bg-gray-700/50'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex-shrink-0 flex items-end border-b border-gray-700 px-4 bg-gray-800/30">
        <TabButton tabName="preview" label="Preview" icon={<EyeIcon />} />
        <TabButton tabName="code" label="Code" icon={<CodeBracketIcon />} />
      </div>
      <div className="flex-grow bg-gray-800 rounded-b-lg overflow-hidden">
        {activeTab === 'preview' ? (
          <Preview code={code} />
        ) : (
          <CodeDisplay code={code} setCode={setCode} />
        )}
      </div>
    </div>
  );
};