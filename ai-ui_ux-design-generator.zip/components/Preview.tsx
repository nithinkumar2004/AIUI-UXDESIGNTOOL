import React from 'react';

interface PreviewProps {
  code: string;
}

export const Preview: React.FC<PreviewProps> = ({ code }) => {
  return (
    <div className="h-full w-full bg-white animate-fade-in">
      <iframe
        srcDoc={code}
        title="Generated UI Preview"
        sandbox="allow-scripts"
        className="w-full h-full border-0"
      />
    </div>
  );
};