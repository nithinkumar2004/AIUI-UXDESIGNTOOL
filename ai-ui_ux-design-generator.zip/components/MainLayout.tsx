import React, { useState, useCallback } from 'react';
import { Header } from './Header';
import { PromptInput } from './PromptInput';
import { OutputPanel } from './OutputPanel';
import { generateUiCode } from '../services/geminiService';
import { WelcomeSplash } from './WelcomeSplash';

const MainLayout: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [code, setCode] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!prompt.trim()) {
      setError('Please enter a design prompt.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setCode('');

    try {
      const generated = await generateUiCode(prompt);
      setCode(generated);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [prompt]);

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans flex flex-col animate-fade-in">
      <Header />
      <main className="flex-grow grid grid-cols-1 lg:grid-cols-2 gap-4 p-4 lg:p-6">
        <div className="flex flex-col gap-4">
          <PromptInput
            prompt={prompt}
            setPrompt={setPrompt}
            onGenerate={handleGenerate}
            isLoading={isLoading}
          />
           {error && (
            <div className="bg-red-900/50 border border-red-700 text-red-300 p-3 rounded-lg text-sm animate-fade-in">
              <p className="font-semibold">Error</p>
              <p>{error}</p>
            </div>
          )}
        </div>
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg shadow-2xl flex flex-col min-h-[60vh] lg:min-h-0">
          {code ? (
            <OutputPanel code={code} setCode={setCode} />
          ) : (
            <WelcomeSplash isLoading={isLoading} />
          )}
        </div>
      </main>
    </div>
  );
};

export default MainLayout;
